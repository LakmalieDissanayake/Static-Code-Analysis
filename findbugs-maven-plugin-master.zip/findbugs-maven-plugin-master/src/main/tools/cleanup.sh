rm *-bundle.jar
rm *.xml
