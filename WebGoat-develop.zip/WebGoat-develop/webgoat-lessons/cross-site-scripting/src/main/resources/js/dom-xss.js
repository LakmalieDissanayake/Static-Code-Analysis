//webgoat.customjs.phoneHome = function (e) {
//    webgoat.customjs.jquery.ajax({
//        method:"POST",
//        url:"/WebGoat/CrossSiteScripting/dom-xss",
//        data:{param1:42,param2:24},
//        headers:{
//            "x-request-with":"dom-xss-vuln"
//        },
//        contentType:'application/x-www-form-urlencoded; charset=UTF-8'
//    });
//}